import re
import tkinter as tk
from tkinter import ttk, messagebox

COURSES = ["1-р курс", "2-р курс", "3-р курс", "4-р курс"]
MAJORS = ["Мэдээллийн технологи", "Механик", "Цахилгаан"]
GENDERS = ["Эрэгтэй", "Эмэгтэй", "Мэдүүлэхгүй"]
CODE_PATTERN = r"V\.[A-Z]{2}[0-9]{2}[A-Z][0-9]{3}"
EMAIL_PATTERN = r"[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+"


def normalize(raw):
    data = {}
    for key in raw:
        if key == "agree":
            data[key] = raw[key]
        else:
            data[key] = raw[key].strip()
    data["code"] = data["code"].upper()
    return data


def validate(data):
    if not 2 <= len(data["name"]) <= 60:
        return "name", "Нэр 2–60 тэмдэгттэй байна."
    if not re.fullmatch(CODE_PATTERN, data["code"]):
        return "code", "Кодын загвар: V.IT23C006."
    if data["course"] not in COURSES:
        return "course", "Курсээ сонгоно уу."
    if data["gender"] not in GENDERS:
        return "gender", "Хүйсийн сонголтоо хийнэ үү."
    if data["major"] not in MAJORS:
        return "major", "Мэргэжлээ сонгоно уу."
    if len(data["email"]) > 254 or not re.fullmatch(EMAIL_PATTERN, data["email"]):
        return "email", "И-мэйлээ name@example.com хэлбэрээр оруул."
    if data["agree"] is not True:
        return "agree", "Мэдээллээ шалгаснаа тэмдэглэнэ үү."
    return None


def summary(data):
    text = f"Нэр: {data['name']}\nКод: {data['code']}\n"
    text += f"Курс: {data['course']}\nХүйс: {data['gender']}\n"
    text += f"Мэргэжил: {data['major']}\nИ-мэйл: {data['email']}"
    return text


root = tk.Tk()
root.title("Student Registration")
root.geometry("640x760")
root.minsize(620, 720)
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

form = ttk.Frame(root, padding=20)
form.grid(row=0, column=0, sticky="nsew")
form.columnconfigure(1, weight=1)

fields = ["name", "code", "course", "gender", "major", "email"]
labels = ["Нэр", "Оюутны код", "Курс", "Хүйс", "Мэргэжил", "И-мэйл"]

variables = {}
for key in fields:
    variables[key] = tk.StringVar(root)
variables["agree"] = tk.BooleanVar(root, value=False)

result_var = tk.StringVar(root)
status_var = tk.StringVar(root, value="Мэдээллээ оруулна уу.")

widgets = {}


def mark_dirty(*args):
    result_var.set("")
    status_var.set("Өөрчлөгдсөн. Дахин шалгуулна уу.")


def submit(event=None):
    raw = {}
    for key in variables:
        raw[key] = variables[key].get()
    data = normalize(raw)
    issue = validate(data)
    result_var.set("")

    if issue:
        key, message = issue
        status_var.set("Алдаатай талбарыг засна уу.")
        messagebox.showwarning("Оруулалтын алдаа", message, parent=root)
        widgets[key].focus_set()
        return "break"

    for key in data:
        variables[key].set(data[key])
    result_var.set(summary(data))
    status_var.set("Шалгалт амжилттай. Файлд хадгалаагүй.")
    return "break"


def clear_form():
    for key in fields:
        variables[key].set("")
    variables["agree"].set(False)
    result_var.set("")
    status_var.set("Мэдээллээ оруулна уу.")
    widgets["name"].focus_set()


title_label = ttk.Label(form, text="Оюутны бүртгэл", font=("Arial", 20, "bold"))
title_label.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 16))

row = 1
for i in range(len(fields)):
    key = fields[i]
    ttk.Label(form, text=labels[i] + ":").grid(row=row, column=0, sticky="w", padx=(0, 14), pady=8)

    if key == "course":
        widget = ttk.Combobox(form, textvariable=variables[key], values=COURSES, state="readonly")
    elif key == "major":
        widget = ttk.Combobox(form, textvariable=variables[key], values=MAJORS, state="readonly")
    elif key == "gender":
        gender_frame = ttk.Frame(form)
        gender_frame.grid(row=row, column=1, sticky="w", pady=8)
        for value in GENDERS:
            radio = ttk.Radiobutton(gender_frame, text=value, value=value, variable=variables[key])
            radio.pack(side="left", padx=(0, 6))
            if value == GENDERS[0]:
                widgets[key] = radio
        row += 1
        continue
    else:
        widget = ttk.Entry(form, textvariable=variables[key])

    widget.grid(row=row, column=1, sticky="ew", pady=8)
    widgets[key] = widget
    row += 1

widgets["agree"] = ttk.Checkbutton(form, text="Мэдээллээ шалгасан", variable=variables["agree"])
widgets["agree"].grid(row=7, column=0, columnspan=2, sticky="w", pady=10)

actions = ttk.Frame(form)
actions.grid(row=8, column=0, columnspan=2, sticky="w", pady=8)

submit_button = ttk.Button(actions, text="Шалгах", command=submit)
submit_button.pack(side="left", padx=(0, 10))

clear_button = ttk.Button(actions, text="Цэвэрлэх", command=clear_form)
clear_button.pack(side="left")

status_label = ttk.Label(form, textvariable=status_var, wraplength=550)
status_label.grid(row=9, column=0, columnspan=2, sticky="w", pady=8)

result_box = ttk.LabelFrame(form, text="Шалгасан мэдээлэл", padding=10)
result_box.grid(row=10, column=0, columnspan=2, sticky="nsew")
form.rowconfigure(10, weight=1)

result_label = ttk.Label(result_box, textvariable=result_var, wraplength=530, justify="left")
result_label.pack(fill="both", expand=True)

for key in variables:
    variables[key].trace_add("write", mark_dirty)

root.bind("<Control-Return>", submit)
widgets["name"].focus_set()

root.mainloop()