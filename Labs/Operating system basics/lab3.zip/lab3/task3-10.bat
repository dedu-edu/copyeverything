@echo off
echo %DATE% %TIME% >> %USERPROFILE%\Desktop\quick_log.txt
