@echo off
del /q %TEMP%\*
