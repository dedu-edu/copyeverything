@echo off
dir C:\Windows /b | find "log"
