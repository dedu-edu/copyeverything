@echo off
cd C:\Lab
copy hello.txt copy.txt
ren "copy.txt" "greeting.txt"