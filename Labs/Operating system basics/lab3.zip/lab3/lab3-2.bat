@echo off
echo "Creating file in lab3 folder"
cd C:\
mkdir C:\Lab
echo "Hello File" > hello.txt