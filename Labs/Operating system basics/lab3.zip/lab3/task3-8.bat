@echo off
echo Сайн уу, %USERNAME%!
