@echo off
echo Хэрэглэгчийн нэр: %USERNAME%
echo Компьютерийн нэр: %COMPUTERNAME%
echo Огноо/Цаг: %DATE% %TIME%
