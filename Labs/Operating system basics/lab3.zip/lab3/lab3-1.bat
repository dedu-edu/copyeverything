@echo off
echo "current path"
cd 
echo "changing to...."
cd C:\