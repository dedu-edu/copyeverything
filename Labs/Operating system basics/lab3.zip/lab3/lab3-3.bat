@echo off
cd C:\Lab
type hello.txt

