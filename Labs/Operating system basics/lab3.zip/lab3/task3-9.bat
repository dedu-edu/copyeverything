@echo off
set /p name=Таны нэрийг оруулна уу: 
echo Сайн уу, %name%!
