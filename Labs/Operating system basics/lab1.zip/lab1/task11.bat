set /p "username=Enter your name: "
if "%username%"=="" (
echo You did not enter a name.
) else (
echo Hello, %username%!
)