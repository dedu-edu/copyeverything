cd C:\lab
copy C:\lab\hello.txt C:\copied.txt
mkdir C:\backup
move C:\copied.txt C:\backup