cd C:\Users\lab1 
echo "hosoo" > notes.txt
ren notes.txt my_notes.txt