set "logfile=log.txt"
echo %date% %time% >> "%logfile%"
echo Written: %date% %time% >> "%logfile%"