if exist data.txt echo "Файл олдлоо"
if not exist data.txt echo "Файл олдсонгүй"