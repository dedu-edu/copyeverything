@echo off
echo Сайн байна уу, %USERNAME%
echo Өнөөдрийн огноо:
date /t
echo Одоогийн цаг:
time /t
pause
