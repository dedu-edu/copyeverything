if exist D:\ echo "Диск байна"
if not exist D:\ echo "Диск байхгүй"