mkdir C:\lab
cd C:\lab
echo Hello World > hello.txt
type C:\lab\hello.txt