echo User name: %USERNAME% 
echo Computer name: %COMPUTERNAME%
echo OS: %OS%
echo Date/time: %date% %time%