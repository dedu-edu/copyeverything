set /p "a=Enter the first number: "
set /p "b=Enter the second number: "
set /a sum=%a%+%b% 
echo %sum%
