@echo off
for /l %%i in (1,1,10) do (
    echo this is the %%ith file > file%%i.txt
)
