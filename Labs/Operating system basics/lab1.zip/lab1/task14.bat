cd C:\
xcopy Documents Backup /E /I /Y /H
set "logfile=log.txt"
echo %date% %time% >> "%logfile%"
echo Backed up in: %date% %time% >> "%logfile%"