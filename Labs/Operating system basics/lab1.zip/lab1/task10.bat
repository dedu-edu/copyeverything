for /L %%i in (1,1,100) do (
  del "%%i.tmp'
) 