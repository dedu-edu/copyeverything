if %USERNAME% == "Admin" (echo "Сайн уу, админ"
)else (echo "Сайн уу энгийн хэрэглэгч")